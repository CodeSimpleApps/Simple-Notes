### Simple-Notes - A simple note taking app with coredata
