### Simple-Notes - simple note taking app with coredata
